public class dataMahasiswa {
   
    public String nama;
    public long nim;
    public char jenisKelamin;
    public double ipk;
    
}
