public class PersegiPanjang {
    public int panjang;
    public int lebar;
}
